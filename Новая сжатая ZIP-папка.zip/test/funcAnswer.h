int funcAnswer(char answer, char a, char b, char c, char d);
